class Role:
    MANAGER = "Manager"
    ADMIN = "Admin"
    STAFF = "Staff"